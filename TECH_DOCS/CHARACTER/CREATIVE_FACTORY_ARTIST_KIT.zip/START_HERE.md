# Creative Factory — комплект художнику

Пять макетов HAIR/HEAD/TOP/BOTTOM/SHOES, 30 октября 2026. Утверждённое тело 01432c7.

Начать с [TECH_DOCS/README.md](TECH_DOCS/README.md). Рисовать поверх TEMPLATE, экспортировать без подложки в CHARACTER. Контур 2 px; фазы движения вручную не рисовать.
